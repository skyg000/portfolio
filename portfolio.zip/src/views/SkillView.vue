<template lang="">
  <SkillViews />
  
</template>
<script>
import SkillViews from '../components/SkillViews.vue';
export default {
  name: 'SkillView',
    components: {
      SkillViews
    }
}
</script>
<style >
  
</style>
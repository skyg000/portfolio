<template lang="">
  <ContactViews />

</template>
<script>
import ContactViews from '../components/ContactViews.vue';
export default {
name: 'ContactView',
  components: {
    ContactViews
  }
}
</script>
<style >

</style>
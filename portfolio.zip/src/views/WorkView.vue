<template lang="">
    <WorkViews />
  
</template>
<script>
import WorkViews from '../components/WorkViews.vue';
export default {
  name: 'WorkView',
    components: {
        WorkViews
    }
}
</script>
<style >
  
</style>